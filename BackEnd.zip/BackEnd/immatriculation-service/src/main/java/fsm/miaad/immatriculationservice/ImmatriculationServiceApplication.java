package fsm.miaad.immatriculationservice;

import fsm.miaad.immatriculationservice.entities.*;
import fsm.miaad.immatriculationservice.repositories.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;

@SpringBootApplication
public class ImmatriculationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImmatriculationServiceApplication.class, args);
		System.out.println("SOAP Server started, listening on address: *, port: 1234");
		System.out.println("====================================================");
	}

	@Bean
	CommandLineRunner start(OwnerRepository ownerRepository, VehicleRepository vehicleRepository, RepositoryRestConfiguration repositoryRestConfiguration){
		repositoryRestConfiguration.exposeIdsFor(Owner.class);
		repositoryRestConfiguration.exposeIdsFor(Vehicle.class);

		return args -> {
			//  UserEntity(Long id, String login, String password, String firstname, String lastname, String profile, List<ContactEntity> contacts)
//			Vector<UserEntity> userEntities=new Vector<>();



			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			ArrayList<Vehicle> vehicles=new ArrayList<>();
			Owner owner1=new Owner(null,"hafida","hatim",dateFormat.parse("19/05/2001"),"hafida@gmail.com",null);
			Owner owner2=new Owner(null,"fatima","bouzakraoui",dateFormat.parse("23/03/2001"),"fatima@gmail.com",null);

			Vehicle vehicle1=new Vehicle(null,"78945-b-25","renault", 7,"3 Series",owner1);
			Vehicle vehicle2=new Vehicle(null,"76324-A-10","Ford", 6,"Focus",owner1);
			Vehicle vehicle3=new Vehicle(null,"13456-A-34","BMW", 8,"C-Class",owner2);
			owner1=ownerRepository.save(owner1);
			vehicles=new ArrayList<>();
			vehicles.add(vehicleRepository.save(vehicle1));
			vehicles.add(vehicleRepository.save(vehicle2));
			owner1.setVehicles(vehicles);
			ownerRepository.save(owner1);

			owner2=ownerRepository.save(owner2);
			vehicles=new ArrayList<>();
			vehicles.add(vehicleRepository.save(vehicle3));
			owner2.setVehicles(vehicles);
			ownerRepository.save(owner2);


//
		};
	}
}


